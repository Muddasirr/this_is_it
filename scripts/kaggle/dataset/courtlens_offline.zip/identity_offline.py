"""Kit + jersey clustering without Postgres (same rules as identity.py)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from jersey_ocr import prefer_jersey_number
from vision import Detection

COLOR_SIM_THRESHOLD = 0.72
CLOSEUP_BOX_FRAC = 0.18
MIN_PLAYER_BOX_FRAC = 0.0008
try:
    from court_format import max_auto_players as _max_auto

    MAX_AUTO_PLAYERS = _max_auto()
except Exception:
    MAX_AUTO_PLAYERS = 16


def median_box_frac(features: dict | None, bbox_series: list | None = None) -> float:
    series = list(bbox_series or []) or list((features or {}).get("bbox_series") or [])
    fracs: list[float] = []
    for pt in series:
        w = float(pt.get("frame_w") or 0) or 1280.0
        h = float(pt.get("frame_h") or 0) or 720.0
        bw = max(0.0, float(pt.get("x2", 0)) - float(pt.get("x1", 0)))
        bh = max(0.0, float(pt.get("y2", 0)) - float(pt.get("y1", 0)))
        fracs.append((bw * bh) / (w * h + 1e-6))
    if not fracs:
        return 0.0
    fracs.sort()
    return fracs[len(fracs) // 2]


def is_on_court_person(features: dict | None, bbox_series: list | None = None) -> bool:
    frac = median_box_frac(features, bbox_series)
    return MIN_PLAYER_BOX_FRAC <= frac <= CLOSEUP_BOX_FRAC


@dataclass
class TrackView:
    track_key: str
    start_ms: int
    end_ms: int
    confidence: float
    features: dict[str, Any] = field(default_factory=dict)
    class_name: str = "person"
    bbox_series: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class PlayerCluster:
    player_key: str
    display_name: str
    kit: str
    shirt_number: int | None
    jersey_confidence: float
    track_keys: list[str]
    color_hist: list[float] | None
    thumb_path: str | None = None


def detections_to_tracks(detections: list[Detection]) -> list[TrackView]:
    out: list[TrackView] = []
    for d in detections:
        feats = dict(d.features or {})
        feats.setdefault("class", d.class_name)
        feats["bbox_series"] = list(d.bbox_series or [])
        out.append(
            TrackView(
                track_key=d.track_key,
                start_ms=d.start_ms,
                end_ms=d.end_ms,
                confidence=d.confidence,
                features=feats,
                class_name=d.class_name,
                bbox_series=list(d.bbox_series or []),
            )
        )
    return out


def propose_players(tracks: list[TrackView]) -> tuple[list[PlayerCluster], dict[str, str]]:
    """Return player clusters + map track_key → player_key."""
    persons = [t for t in tracks if t.class_name == "person" or (t.features or {}).get("class") == "person"]
    on_court = [t for t in persons if is_on_court_person(t.features, t.bbox_series)]
    persons = on_court or persons
    clusters = _cluster_tracks(persons)
    clusters = sorted(clusters, key=lambda c: sum(t.end_ms - t.start_ms for t in c), reverse=True)[
        :MAX_AUTO_PLAYERS
    ]

    meta: list[dict] = []
    for cluster in clusters:
        number, nconf = _cluster_jersey(cluster)
        hist = _cluster_mean_hist(cluster)
        thumb = None
        best_score = -1.0
        for t in cluster:
            tp = (t.features or {}).get("thumb_path")
            sc = float((t.features or {}).get("thumb_score") or 0)
            # Prefer on-court crops over broadcast face close-ups for avatars
            frac = median_box_frac(t.features, t.bbox_series)
            if frac > CLOSEUP_BOX_FRAC:
                sc *= 0.05
            if tp and sc > best_score:
                best_score = sc
                thumb = tp
        meta.append(
            {
                "tracks": cluster,
                "jersey_number": number,
                "jersey_confidence": nconf,
                "has_color": hist is not None,
                "color_hist": hist,
                "duration": sum(t.end_ms - t.start_ms for t in cluster),
                "thumb_path": thumb,
                "kit": "A",
            }
        )
    _assign_kits(meta)

    # Unique shirt numbers within kit
    used: dict[str, set[int]] = {"A": set(), "B": set()}
    next_free = {"A": 1, "B": 1}
    players: list[PlayerCluster] = []
    track_to_player: dict[str, str] = {}

    for m in meta:
        kit = m.get("kit") or "A"
        num = m.get("jersey_number")
        if num is not None and int(num) not in used[kit]:
            shirt = int(num)
        else:
            shirt = next_free[kit]
            while shirt in used[kit]:
                shirt += 1
            next_free[kit] = shirt + 1
        used[kit].add(shirt)
        pkey = f"kit{kit}_{shirt}"
        display = f"Kit {kit} #{shirt}"
        cluster = m["tracks"]
        players.append(
            PlayerCluster(
                player_key=pkey,
                display_name=display,
                kit=kit,
                shirt_number=shirt,
                jersey_confidence=float(m.get("jersey_confidence") or 0),
                track_keys=[t.track_key for t in cluster],
                color_hist=m.get("color_hist"),
                thumb_path=m.get("thumb_path"),
            )
        )
        for t in cluster:
            track_to_player[t.track_key] = pkey

    return players, track_to_player


def _cluster_jersey(cluster: list[TrackView]) -> tuple[int | None, float]:
    votes: list[tuple[int, float]] = []
    for t in cluster:
        feats = t.features or {}
        num = feats.get("jersey_number")
        if num is None:
            continue
        conf = float(feats.get("jersey_confidence") or 0.5)
        votes.append((int(num), conf))
        for _ in range(max(0, int(feats.get("jersey_votes") or 1) - 1)):
            votes.append((int(num), conf))
    return prefer_jersey_number(votes)


def _cluster_mean_hist(cluster: list[TrackView]) -> list[float] | None:
    hists = []
    for t in cluster:
        h = (t.features or {}).get("color_hist")
        if h:
            hists.append(list(h))
    if not hists:
        return None
    return _mean_hist(hists)


def _dominant_hue_bin(hist: list[float] | None) -> float:
    if not hist or len(hist) < 64:
        return 3.5
    bins = 8
    weights = [0.0] * bins
    for i, v in enumerate(hist[:64]):
        weights[i // bins] += float(v)
    total = sum(weights) or 1.0
    return sum(i * w for i, w in enumerate(weights)) / total


def _assign_kits(cluster_meta: list[dict]) -> None:
    if not cluster_meta:
        return
    hues = [_dominant_hue_bin(m.get("color_hist")) for m in cluster_meta]
    if len(cluster_meta) == 1 or max(hues) - min(hues) < 0.8:
        for m in cluster_meta:
            m["kit"] = "A"
        return
    c0, c1 = min(hues), max(hues)
    for _ in range(8):
        g0, g1 = [], []
        for h in hues:
            (g0 if abs(h - c0) <= abs(h - c1) else g1).append(h)
        if not g0 or not g1:
            break
        c0 = sum(g0) / len(g0)
        c1 = sum(g1) / len(g1)
    if c0 > c1:
        c0, c1 = c1, c0
    for m, h in zip(cluster_meta, hues):
        m["kit"] = "A" if abs(h - c0) <= abs(h - c1) else "B"


def _cluster_tracks(tracks: list[TrackView]) -> list[list[TrackView]]:
    if not tracks:
        return []
    ordered = sorted(tracks, key=lambda t: t.end_ms - t.start_ms, reverse=True)
    clusters: list[list[TrackView]] = []
    centroids: list[list[float] | None] = []
    for track in ordered:
        hist = (track.features or {}).get("color_hist")
        placed = False
        for i, cluster in enumerate(clusters):
            if _overlaps_any(track, cluster):
                continue
            cent = centroids[i]
            if hist and cent:
                if _cosine(hist, cent) >= COLOR_SIM_THRESHOLD:
                    cluster.append(track)
                    centroids[i] = _mean_hist([cent, hist])
                    placed = True
                    break
            elif hist is None and cent is None:
                if _temporal_gap_ok(track, cluster):
                    cluster.append(track)
                    placed = True
                    break
        if not placed:
            clusters.append([track])
            centroids.append(list(hist) if hist else None)
    return clusters


def _overlaps_any(track: TrackView, cluster: list[TrackView]) -> bool:
    for other in cluster:
        if track.start_ms <= other.end_ms and other.start_ms <= track.end_ms:
            overlap = min(track.end_ms, other.end_ms) - max(track.start_ms, other.start_ms)
            if overlap > 400:
                return True
    return False


def _temporal_gap_ok(track: TrackView, cluster: list[TrackView], max_gap_ms: int = 8000) -> bool:
    gaps = []
    for other in cluster:
        if track.start_ms > other.end_ms:
            gaps.append(track.start_ms - other.end_ms)
        elif other.start_ms > track.end_ms:
            gaps.append(other.start_ms - track.end_ms)
    return bool(gaps) and min(gaps) <= max_gap_ms


def _cosine(a: list[float], b: list[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    na = sum(x * x for x in a) ** 0.5
    nb = sum(y * y for y in b) ** 0.5
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


def _mean_hist(hists: list[list[float]]) -> list[float]:
    n = len(hists[0])
    acc = [0.0] * n
    for h in hists:
        for i, v in enumerate(h):
            acc[i] += v
    inv = 1.0 / len(hists)
    acc = [v * inv for v in acc]
    norm = sum(v * v for v in acc) ** 0.5 or 1.0
    return [v / norm for v in acc]
